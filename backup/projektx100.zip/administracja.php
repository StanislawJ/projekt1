<div id="panel_adm">siema</div>
<div id='dane_adm'><?php require_once('do_zatwierdzenia_adm.php') ?></div>

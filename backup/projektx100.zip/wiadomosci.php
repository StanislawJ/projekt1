<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta charset="utf-8">
  	<title></title>

  <!ikona przy nazwie strony>
  	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">

  	<meta charset="utf-8"/>
  	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


  	<link rel="stylesheet" type="text/css" href="style.css" media="all">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">


  	<script language="JavaScript" src="gen_validatorv4.js" type="text/javascript" xml:space="preserve"></script>
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


  </head>
  <body>

<div id='panel_wiad'>
  <?php require_once('wiadomosci_panel.php') ?>
</div>

<div id='text_wiad'>
    <?php require_once('lista_wiad_odebrane.php') ?>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>


</html>

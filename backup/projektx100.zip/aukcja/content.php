<!-- Sample by Mr. M. - Confederation College - IMD Program -->



<div id="galery">
<div class="linne">

<hr>

<a class="Aimg" href="#" data-toggle="modal" data-target=".pop-up-1">
<img src="images/<?php echo $ID;?>1.jpg" width="150" class="img-responsive img-rounded center-block" alt="">
</a>

<hr>

<a class="Aimg" href="#" data-toggle="modal" data-target=".pop-up-2">
<img src="images/<?php echo $ID;?>2.jpg" width="150" class="img-responsive img-rounded center-block" alt="">
</a>

<hr>

<a class="Aimg" href="#" data-toggle="modal" data-target=".pop-up-3">
<img src="images/<?php echo $ID;?>3.jpg" width="150" class="img-responsive img-rounded center-block" alt="">
</a>

<hr>

<a class="Aimg" href="#" data-toggle="modal" data-target=".pop-up-4">
<img src="images/<?php echo $ID;?>4.jpg" width="150" class="img-responsive img-rounded center-block" alt="">
</a>

<hr>

<a class="Aimg" href="#" data-toggle="modal" data-target=".pop-up-5">
<img src="images/<?php echo $ID;?>5.jpg" width="150" class="img-responsive img-rounded center-block" alt="">
</a>

<hr>

<a class="Aimg" href="#" data-toggle="modal" data-target=".pop-up-6">
<img src="images/<?php echo $ID;?>6.jpg" width="150" class="img-responsive img-rounded center-block" alt="">
</a>

<hr>

<!--  Modal content for the mixer image example -->
  <div class="modal fade pop-up-1" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">

        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="modal-body">
        <img src="images/<?php echo $ID;?>1.jpg" class="img-responsive img-rounded center-block" alt="">
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal mixer image -->

 <!--  Modal content for the lion image example -->
  <div class="modal fade pop-up-2" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel-2" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">

        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="modal-body">
        <img src="images/<?php echo $ID;?>2.jpg" class="img-responsive img-rounded center-block" alt="">
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal mixer image -->



  <div class="modal fade pop-up-3" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel-2" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">

        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="modal-body">
        <img src="images/<?php echo $ID;?>3.jpg" class="img-responsive img-rounded center-block" alt="">
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal mixer image -->

  <div class="modal fade pop-up-4" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel-2" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">

        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="modal-body">
        <img src="images/<?php echo $ID;?>4.jpg" class="img-responsive img-rounded center-block" alt="">
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal mixer image -->

  <div class="modal fade pop-up-5" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel-2" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">

        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="modal-body">
        <img src="images/<?php echo $ID;?>5.jpg" class="img-responsive img-rounded center-block" alt="">
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal mixer image -->


  <div class="modal fade pop-up-6" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel-2" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">

        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="modal-body">
        <img src="images/<?php echo $ID;?>6.jpg" class="img-responsive img-rounded center-block" alt="">
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal mixer image -->


</div> <!-- /.row -->
</div> <!-- /.container -->

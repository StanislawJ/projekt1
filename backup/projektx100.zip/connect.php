<?php

	$host = "localhost";
	$db_user = "daki777";
	$db_password = "admin123";
	$db_name = "aukcjoner";

?>
